export const arrayCards = [
    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '8'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '2'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '6'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '9'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '5'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '12'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '4'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '17'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '13'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: 14
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '15'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '27'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '37'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '47'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '57'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '67'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '77'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '87'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '97'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '71'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '72'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '73'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '74'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '75'
    },
    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '76'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '77'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '78'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '79'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

    {
        id: 1,
        img: '../assets/images/tri-porosenka.jpg',
        name: 'Три поросенка',
        author: 'Сергей Михалков',
        time: '7'
    },

]