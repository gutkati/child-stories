let btnBack = document.getElementById('btn-back')
btnBack.addEventListener('click', () => {
     window.history.back();
})